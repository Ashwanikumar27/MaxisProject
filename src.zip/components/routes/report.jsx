import React from "react";
import { Route } from 'react-router-dom';
import AutomatedReport from '../../pages/report/automatedreport';

const ReportFlow = ({...props}) => {
	return (
		<React.Fragment>
	        <Route exact path={`${props.match.url}/automatedreport`} component={AutomatedReport} />
    	</React.Fragment>
	)
}

export default ReportFlow;
