import { combineReducers } from 'redux';
import { GET_EAS_CONFIGURATION_DATA_PENDING, GET_EAS_CONFIGURATION_DATA_FULFILLED, GET_EAS_CONFIGURATION_DATA_REJECTED,
		 VSN_SEARCH_BY_BRN_PENDING, VSN_SEARCH_BY_BRN_FULFILLED, VSN_SEARCH_BY_BRN_REJECTED,
		 VSN_SEARCH_BY_MSISDN_VSN_PENDING, VSN_SEARCH_BY_MSISDN_VSN_FULFILLED, VSN_SEARCH_BY_MSISDN_VSN_REJECTED,
		 FETCH_REG_TYPES_PENDING, FETCH_REG_TYPES_FULFILLED, FETCH_REG_TYPES_REJECTED,
		 FETCH_RATEPLANS_PENDING, FETCH_RATEPLANS_FULFILLED, FETCH_RATEPLANS_REJECTED,
		 FETCH_SIM_TYPES_PENDING, FETCH_SIM_TYPES_FULFILLED, FETCH_SIM_TYPES_REJECTED,
		 FETCH_ZEROLUTION_DEVICES_PENDING, FETCH_ZEROLUTION_DEVICES_FULFILLED, FETCH_ZEROLUTION_DEVICES_REJECTED,
		 FETCH_DONOR_TYPES_PENDING, FETCH_DONOR_TYPES_FULFILLED, FETCH_DONOR_TYPES_REJECTED,
		 COMPANY_INFO_BY_BRN_FULFILLED, COMPANY_INFO_BY_BRN_PENDING, COMPANY_INFO_BY_BRN_REJECTED,
		 FETCH_ZEROLUTION_DEVICE_INFO_PENDING, FETCH_ZEROLUTION_DEVICE_INFO_FULFILLED, FETCH_ZEROLUTION_DEVICE_INFO_REJECTED,
		 FETCH_DEVICE_FUNDS_PENDING, FETCH_DEVICE_FUNDS_FULFILLED, FETCH_DEVICE_FUNDS_REJECTED,
		 FETCH_FLEXI_FUND_DEVICES_PENDING, FETCH_FLEXI_FUND_DEVICES_FULFILLED, FETCH_FLEXI_FUND_DEVICES_REJECTED,
		 SEND_FILE_FULFILLED, SEND_FILE_PENDING, SEND_FILE_REJECTED,GET_UPLOADED_FILE_PENDING, GET_UPLOADED_FILE_FULFILLED, GET_UPLOADED_FILE_REJECTED,
		 FETCH_POST_CODE_HINT_PENDING, FETCH_POST_CODE_HINT_FULFILLED, FETCH_POST_CODE_HINT_REJECTED,
		 SUBMISSION_INFO_PENDING,SUBMISSION_INFO_FULFILLED,SUBMISSION_INFO_REJECTED,
		 ACCOUNT_MANAGER_INFO_PENDING,ACCOUNT_MANAGER_INFO_FULFILLED,ACCOUNT_MANAGER_INFO_REJECTED,
		 SUPPORTING_CENTER_INFO_PENDING,SUPPORTING_CENTER_INFO_FULFILLED,SUPPORTING_CENTER_INFO_REJECTED,
		 SUBMISSION_SEND_FILE_PENDING,SUBMISSION_SEND_FILE_FULFILLED,SUBMISSION_SEND_FILE_REJECTED,
		 SUBMISSION_UPLOAD_FILE_PENDING,SUBMISSION_UPLOAD_FILE_FULFILLED,SUBMISSION_UPLOAD_FILE_REJECTED,
		 FETCH_VAS_POPUP_DATA_PENDING, FETCH_VAS_POPUP_DATA_FULFILLED, FETCH_VAS_POPUP_DATA_REJECTED,
		 VALIDATE_LINE_PENDING ,VALIDATE_LINE_FULFILLED ,VALIDATE_LINE_REJECTED,
		 FETCH_DEVICE_FUND_CONTRACTS_PENDING, FETCH_DEVICE_FUND_CONTRACTS_FULFILLED, FETCH_DEVICE_FUND_CONTRACTS_REJECTED,
		 FETCH_FUND_DEVICE_INFO_PENDING ,FETCH_FUND_DEVICE_INFO_FULFILLED ,FETCH_FUND_DEVICE_INFO_REJECTED,
		 GET_DEVICE_FUND_CONTRACTS_PENDING, GET_DEVICE_FUND_CONTRACTS_FULFILLED, GET_DEVICE_FUND_CONTRACTS_REJECTED,
		 GET_ADDED_FUND_DEVICES_PENDING, GET_ADDED_FUND_DEVICES_FULFILLED,GET_ADDED_FUND_DEVICES_REJECTED,
		 SET_DEVICE_FUNDS_PENDING, SET_DEVICE_FUNDS_FULFILLED, SET_DEVICE_FUNDS_REJECTED ,
		 APPROVAL_SUBMISSION_INFO_PENDING,APPROVAL_SUBMISSION_INFO_FULFILLED,APPROVAL_SUBMISSION_INFO_REJECTED,
		 VALIDATE_PARENTID_HIERID_PENDING,VALIDATE_PARENTID_HIERID_FULFILLED,VALIDATE_PARENTID_HIERID_REJECTED,
		 GET_PAYMENT_DETAILS_PENDING,GET_PAYMENT_DETAILS_FULFILLED,GET_PAYMENT_DETAILS_REJECTED,
		 GET_VIEW_SUBMISSION_INFO_PENDING,GET_VIEW_SUBMISSION_INFO_FULFILLED,GET_VIEW_SUBMISSION_INFO_REJECTED,
		 FETCH_ASSIGN_TO_LIST_PENDING, FETCH_ASSIGN_TO_LIST_FULFILLED, FETCH_ASSIGN_TO_LIST_REJECTED,
		 RESET_PARENTID_HIERID_STATUS_PENDING,RESET_PARENTID_HIERID_STATUS_FULFILLED,RESET_PARENTID_HIERID_STATUS_REJECTED,
		 VAS_RULE_CHECK_PENDING, VAS_RULE_CHECK_FULFILLED, VAS_RULE_CHECK_REJECTED,
		 CONTRACT_CHECK_PENDING, CONTRACT_CHECK_FULFILLED, CONTRACT_CHECK_REJECTED,
		 SET_APPROVAL_DEVICE_FUNDS_PENDING, SET_APPROVAL_DEVICE_FUNDS_FULFILLED, SET_APPROVAL_DEVICE_FUNDS_REJECTED,
		 GET_VSN_DETAILS_PENDING, GET_VSN_DETAILS_FULFILLED, GET_VSN_DETAILS_REJECTED,
		 GET_PROMOTIONS_PENDING,GET_PROMOTIONS_FULFILLED,GET_PROMOTIONS_REJECTED,
		 GET_DEVICE_LIST_ERF_PENDING,GET_DEVICE_LIST_ERF_FULFILLED,GET_DEVICE_LIST_ERF_REJECTED,
		 SET_OLD_DEVICE_FUNDS_PENDING, SET_OLD_DEVICE_FUNDS_FULFILLED, SET_OLD_DEVICE_FUNDS_REJECTED,
		 SEARCH_PAYMENT_PENDING,SEARCH_PAYMENT_FULFILLED,SEARCH_PAYMENT_REJECTED,
		 GET_PROD_GRP_CHANGE_PENDING,GET_PROD_GRP_CHANGE_FULFILLED,GET_PROD_GRP_CHANGE_REJECTED,
		 SEARCH_CHANGE_PENDING,SEARCH_CHANGE_FULFILLED,SEARCH_CHANGE_REJECTED,
		 SEND_FILE_URL_DEALER_SEARCH_PENDING, SEND_FILE_URL_DEALER_SEARCH_FULFILLED, SEND_FILE_URL_DEALER_SEARCH_REJECTED,
		 GET_AUTOMATED_REPORT_NAME_PENDING,
		 GET_AUTOMATED_REPORT_NAME_FULFILLED,GET_AUTOMATED_REPORT_NAME_REJECTED,
		 GENERATE_REPORT_DATA_PENDING, GENERATE_REPORT_DATA_FULFILLED, GENERATE_REPORT_DATA_REJECTED,
		 GET_REPORTS_EXECUTION_HISTORY_PENDING, GET_REPORTS_EXECUTION_HISTORY_FULFILLED, GET_REPORTS_EXECUTION_HISTORY_REJECTED,
		 GET_CUSTOM_REPORT_INPUTS_PENDING, GET_CUSTOM_REPORT_INPUTS_FULFILLED, GET_CUSTOM_REPORT_INPUTS_REJECTED,
		 FETCH_REG_TYPES_OBS_PENDING,FETCH_REG_TYPES_OBS_FULFILLED,FETCH_REG_TYPES_OBS_REJECTED,
		 FETCH_RATEPLANS_OBS_PENDING,FETCH_RATEPLANS_OBS_FULFILLED,FETCH_RATEPLANS_OBS_REJECTED,
		 VSN_OBS_SEARCH_BY_BRN_PENDING,VSN_OBS_SEARCH_BY_BRN_FULFILLED,VSN_OBS_SEARCH_BY_BRN_REJECTED,
		 GET_BCC_VALIDATION_PENDING,GET_BCC_VALIDATION_FULFILLED,GET_BCC_VALIDATION_REJECTED,
		 GET_RATEPLAN_DEVICE_MAP_LIST_PENDING,GET_RATEPLAN_DEVICE_MAP_LIST_FULFILLED,GET_RATEPLAN_DEVICE_MAP_LIST_REJECTED,
		 VALIDATE_LINE_EXISTING_GROUP_PENDING,VALIDATE_LINE_EXISTING_GROUP_FULFILLED,VALIDATE_LINE_EXISTING_GROUP_REJECTED,
		 GET_BULK_USERS_PENDING,GET_BULK_USERS_FULFILLED,GET_BULK_USERS_REJECTED,
		 GET_BULK_ORDERS_DATA_PENDING,GET_BULK_ORDERS_DATA_FULFILLED,GET_BULK_ORDERS_DATA_REJECTED,
		 GET_SIM_TYPE_REPLCMT_REASON_PENDING,GET_SIM_TYPE_REPLCMT_REASON_FULFILLED,GET_SIM_TYPE_REPLCMT_REASON_REJECTED,
		 GET_TEMPLATE_BULKSIM_PENDING,GET_TEMPLATE_BULKSIM_FULFILLED,GET_TEMPLATE_BULKSIM_REJECTED,
		 GET_OBS_DEVICES_PENDING, GET_OBS_DEVICES_FULFILLED, GET_OBS_DEVICES_REJECTED,
		 FETCH_OBS_DEVICE_INFO_PENDING, FETCH_OBS_DEVICE_INFO_FULFILLED, FETCH_OBS_DEVICE_INFO_REJECTED

		  
		} from '../action-types/configuration';


const initialMetaState = {
	GET_EAS_CONFIGURATION_DATA_STATUS: 'DEFAULT',
	VSN_SEARCH_BY_BRN_STATUS: 'DEFAULT',
	VSN_SEARCH_BY_MSISDN_VSN_STATUS: 'DEFAULT',
	FETCH_REG_TYPES_STATUS: 'DEFAULT',
	FETCH_RATEPLANS_STATUS:'DEFAULT',
	FETCH_SIM_TYPES_STATUS: 'DEFAULT',
	FETCH_ZEROLUTION_DEVICES_STATUS: 'DEFAULT',
	FETCH_DONOR_TYPES_STATUS: 'DEFAULT',
	FETCH_ZEROLUTION_DEVICE_STATUS: 'DEFAULT',
	FETCH_DEVICE_FUNDS_STATUS: 'DEFAULT',
	FETCH_FLEXI_FUND_DEVICES_STATUS: 'DEFAULT',
	COMPANY_INFO_BY_BRN_STATUS: 'DEFAULT',
	SEND_FILE_STATUS:'DEFAULT',
	GET_UPLOADED_FILE_STATUS: 'DEFAULT',
	FETCH_POST_CODE_HINT_STATUS: 'DEFAULT',
	SUBMISSION_INFO_STATUS:'DEFAULT',
	SET_COMPANY_INFO_STATUS:'DEFAULT',
	ACCOUNT_MANAGER_INFO_STATUS:'DEFAULT',
	SUPPORTING_CENTER_INFO_STATUS:'DEFAULT',
	SUBMISSION_SEND_FILE_STATUS:'DEFAULT',
	SUBMISSION_UPLOAD_FILE_STATUS:'DEFAULT',
	FETCH_VAS_POPUP_DATA_STATUS:'DEFAULT',
	VALIDATE_LINE_STATUS:'DEFAULT',
	FETCH_DEVICE_FUND_CONTRACTS_STATUS:'DEFAULT',
	FETCH_FUND_DEVICE_INFO_STATUS:'DEFAULT',
	flexiFundContractTaken:false,
	byodContractTaken:false,
	ERROR_CODE: null,
	errorMessage: [],
	GET_DEVICE_FUND_CONTRACTS_STATUS:'DEFAULT',
	GET_ADDED_FUND_DEVICES_STATUS: 'DEFAULT',
	SET_DEVICE_FUNDS_STATUS: 'DEFAULT',
	APPROVAL_SUBMISSION_INFO_STATUS:'DEFAULT',
	VALIDATE_PARENTID_HIERID_STATUS:'DEFAULT',
	GET_PAYMENT_DETAILS_STATUS:'DEFAULT',
	GET_VIEW_SUBMISSION_INFO_STATUS:'DEFAULT',
	FETCH_ASSIGN_TO_LIST_STATUS: 'DEFAULT',
	VAS_RULE_CHECK_STATUS: 'DEFAULT',
	CONTRACT_CHECK_STATUS:'DEFAULT',
	SET_APPROVAL_DEVICE_FUNDS_STATUS: 'DEFAULT',
	GET_VSN_DETAILS_STATUS: 'DEFAULT',
	GET_FUND_AMOUNT_STATUS: 'DEFAULT',
	GET_PROMOTIONS_STATUS:'DEFAULT',
	GET_DEVICE_LIST_ERF_STATUS:'DEFAULT',
	SET_OLD_DEVICE_FUNDS_STATUS:'DEFAULT',
	SEARCH_PAYMENT_STATUS:'DEFAULT',
	GET_PROD_GRP_CHANGE_STATUS:'DEFAULT',
	SEARCH_CHANGE_STATUS:'DEFAULT',
	SEND_FILE_URL_DEALER_SEARCH_STATUS: 'DEFAULT',
	GET_AUTOMATED_REPORT_NAME_STATUS: 'DEFAULT',
	GENERATE_REPORT_DATA_STATUS: 'DEFAULT',
	GET_REPORTS_EXECUTION_HISTORY_STATUS: 'DEFAULT',
	GET_CUSTOM_REPORT_INPUTS_STATUS:'DEFAULT',
	FETCH_REG_TYPES_OBS_STATUS:'DEFAULT',
	FETCH_RATEPLANS_OBS_STATUS:'DEFAULT',
	VSN_OBS_SEARCH_BY_BRN_STATUS:'DEFAULT',
	GET_BCC_VALIDATION_STATUS:'DEFAULT',
	GET_RATEPLAN_DEVICE_MAP_LIST_STATUS:'DEFAULT',
	VALIDATE_LINE_EXISTING_GROUP_STATUS:'DEFAULT',
	GET_BULK_USERS_STATUS:'DEFAULT',
	GET_BULK_ORDERS_DATA_STATUS:'DEFAULT',
	GET_SIM_TYPE_REPLCMT_REASON_STATUS:'DEFAULT',
	GET_TEMPLATE_BULKSIM_STATUS:'DEFAULT',
	GET_OBS_DEVICES_STATUS: 'DEFAULT',
	FETCH_OBS_DEVICE_INFO_STATUS:'DEFAULT'
}

const initialDataState = {
	bundleTypes: [],
	orderCategories: [],
	vsnServices:[],
	regTypes:[],
	postCodeHint: [],
	ratePlans:[],
	simTypes:[
		{key: 1, text: 'Micro', value: 'Micro'},
		{key: 2, text: 'Mini', value: 'Mini'},
		{key: 3, text: 'Normal', value: 'Normal'}
	],
	deviceContracts:[
		{ key: '0', text: 'Normal', value: 'Normal' },
		{ key: '1', text: 'Zerolution', value: 'Zerolution' }
	],
	planTypes:[
		{ key: '0', text: 'Prepaid', value: 'Prepaid' },
		{ key: '1', text: 'PostPaid', value: 'PostPaid' },
	],
	zerolutionDevices:[],
	flexiFundDevices:[],
	accMngrList:[],
	suppcenterList:[],
	vas:[],
	uploadedDocDetails:'',
	addressDetails:'',
	vasOptionals:[],
	vasMandatory:[],
	vasContracts:[],
	lineValidation:'',
	vasIddCountries:[],
	dealerInfo:{
		dealerName:'',
        dealerCode:''
	},
	lineDeviceInfo:'',
	validateErrorCode:'',
	validateErrorMessage:[],
	isLineDataValid:false,
	active:false,
	deviceFunds:[],
	msisdnList:[],
	addedFundDevices:[],
	approvalSubmissionInfo:'',
	authList:[],
	marketCode:'',
	marketCodeName:'',
	collectionCodeName:'',
	paymentDetails:'',
	dealerRemarks:'',
	accountCategory:'',
	error:'',
	assignList:[],
	vasMessage:'',
	msisdnContracts:[],
	lineCount:0,
	maxLineCount:100,
	previousFundAmount:0,
	deviceFundsOld:[],
	promotions:[],
	deviceListERF:[],
	isValidVSN:false,
	paymentInfo:'',
	changeStatusRegIdList:[],
	deviceFulfillmentoptions: [
		{ key: '0', text: 'Device delivery by Brightstar', value: 'Device delivery by Brightstar' },
		{ key: '1', text: 'Fulfillment by Trade Partner', value: 'Fulfillment by Trade Partner' },
	],
	tempDocRegId:'',
	reportTypes: [],
	tableHeaders:[],
	tableRows:[],
	reportHistoryExecutionData:'',
	reportInputs:[],
	bccValidation:false,
	bccErrorMessage:'',
	ratePlanDeviceMapList:[],
	validatedDeviceList:[],
		bulkUsers: [],
    bulkRegTypes:[],
    	bulkOrders:[],
	bulkOrderTemplate:[],
	tempMaxLineCount:0,
	obsDevices: []
    
}

function metaReducer(state = initialMetaState, action) {
	// listen to only the action interested for this reducer
	switch (action.type) {
		case GET_VIEW_SUBMISSION_INFO_PENDING:
			return {...state, GET_VIEW_SUBMISSION_INFO_STATUS: 'PENDING'};
		case GET_VIEW_SUBMISSION_INFO_FULFILLED:
			return  {...state, GET_VIEW_SUBMISSION_INFO_STATUS: 'SUCCESS'};
		case GET_VIEW_SUBMISSION_INFO_REJECTED:
			return  {...state, GET_VIEW_SUBMISSION_INFO_STATUS: 'FAILED'};
		case GET_EAS_CONFIGURATION_DATA_PENDING:
			return {...state, GET_EAS_CONFIGURATION_DATA_STATUS: 'PENDING'};
		case GET_EAS_CONFIGURATION_DATA_FULFILLED:
			return  {...state, GET_EAS_CONFIGURATION_DATA_STATUS: 'SUCCESS'};
		case GET_EAS_CONFIGURATION_DATA_REJECTED:
			return  {...state, GET_EAS_CONFIGURATION_DATA_STATUS: 'FAILED'};
		case VSN_SEARCH_BY_BRN_PENDING:
			return {...state, VSN_SEARCH_BY_BRN_STATUS: 'PENDING'};
		case VSN_SEARCH_BY_BRN_FULFILLED:
			return  {...state, VSN_SEARCH_BY_BRN_STATUS: 'SUCCESS'};
		case VSN_SEARCH_BY_BRN_REJECTED:
			return  {...state, VSN_SEARCH_BY_BRN_STATUS: 'FAILED'};
		case VSN_SEARCH_BY_MSISDN_VSN_PENDING:
			return {...state, VSN_SEARCH_BY_MSISDN_VSN_STATUS: 'PENDING'};
		case VSN_SEARCH_BY_MSISDN_VSN_FULFILLED:
			return  {...state, VSN_SEARCH_BY_MSISDN_VSN_STATUS: 'SUCCESS'};
		case VSN_SEARCH_BY_MSISDN_VSN_REJECTED:
			return  {...state, VSN_SEARCH_BY_MSISDN_VSN_STATUS: 'FAILED'};
		case FETCH_REG_TYPES_PENDING:
			return {...state, FETCH_REG_TYPES_STATUS:'PENDING'}
		case FETCH_REG_TYPES_FULFILLED:
			return {...state, FETCH_REG_TYPES_STATUS:'SUCCESS'}
		case FETCH_REG_TYPES_REJECTED:
			return {...state, FETCH_REG_TYPES_STATUS:'FAILED'}
		case FETCH_RATEPLANS_PENDING:
			return {...state,FETCH_RATEPLANS_STATUS:'PENDING'}
		case FETCH_RATEPLANS_FULFILLED:
			return {...state, FETCH_RATEPLANS_STATUS:'SUCCESS'}
		case FETCH_RATEPLANS_REJECTED:
			return {...state, FETCH_RATEPLANS_STATUS:'FAILED'}
		case FETCH_SIM_TYPES_PENDING:
			return {...state, FETCH_SIM_TYPES_STATUS: 'PENDING'}
		case FETCH_SIM_TYPES_FULFILLED:
			return {...state, FETCH_SIM_TYPES_STATUS: 'SUCCESS'}
		case FETCH_SIM_TYPES_REJECTED:
			return {...state, FETCH_SIM_TYPES_STATUS: 'FAILED'}
		case FETCH_ZEROLUTION_DEVICES_PENDING:
			return {...state, FETCH_ZEROLUTION_DEVICES_STATUS: 'PENDING'}
		case FETCH_ZEROLUTION_DEVICES_FULFILLED:
			return {...state, FETCH_ZEROLUTION_DEVICES_STATUS: 'SUCCESS'}
		case FETCH_ZEROLUTION_DEVICES_REJECTED:
			return {...state, FETCH_ZEROLUTION_DEVICES_STATUS: 'FAILED'}
		case FETCH_DONOR_TYPES_PENDING:
			return {...state, FETCH_DONOR_TYPES_STATUS: 'PENDING'}
		case FETCH_DONOR_TYPES_FULFILLED:
			return {...state, FETCH_DONOR_TYPES_STATUS: 'SUCCESS'}
		case FETCH_DONOR_TYPES_REJECTED:
			return {...state, FETCH_DONOR_TYPES_STATUS: 'FAILED'}
		case FETCH_ZEROLUTION_DEVICE_INFO_PENDING:
			return {...state, FETCH_ZEROLUTION_DEVICE_STATUS: 'PENDING'}
		case FETCH_ZEROLUTION_DEVICE_INFO_FULFILLED:
			return {...state, FETCH_ZEROLUTION_DEVICE_STATUS: 'SUCCESS'}
		case FETCH_ZEROLUTION_DEVICE_INFO_REJECTED:
			return {...state, FETCH_ZEROLUTION_DEVICE_STATUS: 'FAILED'}
		case FETCH_DEVICE_FUNDS_PENDING:
			return {...state, FETCH_DEVICE_FUNDS_STATUS: 'PENDING'}
		case FETCH_DEVICE_FUNDS_FULFILLED:
			return {...state, FETCH_DEVICE_FUNDS_STATUS: 'SUCCESS'}
		case FETCH_DEVICE_FUNDS_REJECTED:
			return {...state, FETCH_DEVICE_FUNDS_STATUS: 'FAILED'}
		case FETCH_FLEXI_FUND_DEVICES_PENDING:
			return {...state, FETCH_FLEXI_FUND_DEVICES_STATUS: 'PENDING'}
		case FETCH_FLEXI_FUND_DEVICES_FULFILLED:
			return {...state, FETCH_FLEXI_FUND_DEVICES_STATUS: 'SUCCESS'}
		case FETCH_FLEXI_FUND_DEVICES_REJECTED:
			return {...state, FETCH_FLEXI_FUND_DEVICES_STATUS: 'FAILED'}
		case COMPANY_INFO_BY_BRN_PENDING:
			return { ...state, COMPANY_INFO_BY_BRN_STATUS: 'PENDING' }
		case COMPANY_INFO_BY_BRN_FULFILLED:
			return { ...state, COMPANY_INFO_BY_BRN_STATUS: 'SUCCESS' }
		case COMPANY_INFO_BY_BRN_REJECTED:
			return { ...state, COMPANY_INFO_BY_BRN_STATUS: 'FAILED' }
		case SEND_FILE_FULFILLED:
			return { ...state, SEND_FILE_STATUS: 'SUCCESS' }
		case SEND_FILE_PENDING:
			return { ...state, SEND_FILE_STATUS: 'PENDING' }
		case SEND_FILE_REJECTED:
			return { ...state, SEND_FILE_STATUS: 'FAILED' }
		case GET_UPLOADED_FILE_FULFILLED:
			return { ...state, GET_UPLOADED_FILE_STATUS: 'SUCCESS' }
		case GET_UPLOADED_FILE_PENDING:
			return { ...state, GET_UPLOADED_FILE_STATUS: 'PENDING' }
		case GET_UPLOADED_FILE_REJECTED:
			return { ...state, GET_UPLOADED_FILE_STATUS: 'FAILED' }
		case FETCH_POST_CODE_HINT_PENDING:
			return { ...state, FETCH_POST_CODE_HINT_STATUS: 'PENDING' }
		case FETCH_POST_CODE_HINT_FULFILLED:
			return { ...state, FETCH_POST_CODE_HINT_STATUS: 'SUCCESS' }
		case FETCH_POST_CODE_HINT_REJECTED:
			return { ...state, FETCH_POST_CODE_HINT_STATUS: 'FAILED' }
		case SUBMISSION_INFO_PENDING:
			return { ...state, SUBMISSION_INFO_STATUS: 'PENDING' }
		case SUBMISSION_INFO_FULFILLED:
			return { ...state, SUBMISSION_INFO_STATUS: 'SUCCESS' }
		case SUBMISSION_INFO_REJECTED:
			return { ...state, SUBMISSION_INFO_STATUS: 'FAILED' }
		case ACCOUNT_MANAGER_INFO_PENDING:
			return { ...state, ACCOUNT_MANAGER_INFO_STATUS: 'PENDING' }
		case ACCOUNT_MANAGER_INFO_FULFILLED:
			return { ...state, ACCOUNT_MANAGER_INFO_STATUS: 'SUCCESS' }
		case ACCOUNT_MANAGER_INFO_REJECTED:
			return { ...state, ACCOUNT_MANAGER_INFO_STATUS: 'FAILED' }
		case SUPPORTING_CENTER_INFO_PENDING:
			return { ...state, SUPPORTING_CENTER_INFO_STATUS: 'PENDING' }
		case SUPPORTING_CENTER_INFO_FULFILLED:
			return { ...state, SUPPORTING_CENTER_INFO_STATUS: 'SUCCESS'}
		case SUPPORTING_CENTER_INFO_REJECTED:
			return { ...state, SUPPORTING_CENTER_INFO_STATUS: 'FAILED' }
		case SUBMISSION_SEND_FILE_PENDING:
			return { ...state, SUBMISSION_SEND_FILE_STATUS: 'PENDING' }
		case SUBMISSION_SEND_FILE_FULFILLED:
			return { ...state, SUBMISSION_SEND_FILE_STATUS: 'SUCCESS' }
		case SUBMISSION_SEND_FILE_REJECTED:
			return { ...state, SUBMISSION_SEND_FILE_STATUS: 'FAILED' }
		case SUBMISSION_UPLOAD_FILE_PENDING:
			return { ...state, SUBMISSION_UPLOAD_FILE_STATUS: 'PENDING' }
		case SUBMISSION_UPLOAD_FILE_FULFILLED:
			return { ...state, SUBMISSION_UPLOAD_FILE_STATUS: 'SUCCESS' }
		case SUBMISSION_UPLOAD_FILE_REJECTED:
			return { ...state, SUBMISSION_UPLOAD_FILE_STATUS: 'FAILED' }
		case FETCH_VAS_POPUP_DATA_PENDING:
			return { ...state, FETCH_VAS_POPUP_DATA_STATUS: 'PENDING' }
		case FETCH_VAS_POPUP_DATA_FULFILLED:
			return { ...state, FETCH_VAS_POPUP_DATA_STATUS: 'SUCCESS' }
		case FETCH_VAS_POPUP_DATA_REJECTED:
			return { ...state, FETCH_VAS_POPUP_DATA_STATUS: 'FAILED' }
		case VALIDATE_LINE_PENDING:
			return { ...state, VALIDATE_LINE_STATUS: 'PENDING' }
		case VALIDATE_LINE_FULFILLED:
			return { ...state, VALIDATE_LINE_STATUS: 'SUCCESS' }
		case VALIDATE_LINE_REJECTED:
			return { ...state, VALIDATE_LINE_STATUS: 'FAILED' }
		case FETCH_DEVICE_FUND_CONTRACTS_PENDING:
			return { ...state, FETCH_DEVICE_FUND_CONTRACTS_STATUS: 'PENDING' }
		case FETCH_DEVICE_FUND_CONTRACTS_FULFILLED:
			return { ...state, FETCH_DEVICE_FUND_CONTRACTS_STATUS: 'SUCCESS' }
		case FETCH_DEVICE_FUND_CONTRACTS_REJECTED:
			return { ...state, FETCH_DEVICE_FUND_CONTRACTS_STATUS: 'FAILED' }
		case FETCH_FUND_DEVICE_INFO_PENDING:
			return { ...state, FETCH_FUND_DEVICE_INFO_STATUS: 'PENDING' }
		case FETCH_FUND_DEVICE_INFO_FULFILLED:
			return { ...state, FETCH_FUND_DEVICE_INFO_STATUS: 'SUCCESS' }
		case FETCH_FUND_DEVICE_INFO_REJECTED:
			return { ...state, FETCH_FUND_DEVICE_INFO_STATUS: 'FAILED' }
		case GET_DEVICE_FUND_CONTRACTS_PENDING:
			return { ...state, GET_DEVICE_FUND_CONTRACTS_STATUS: 'PENDING' }
		case GET_DEVICE_FUND_CONTRACTS_FULFILLED:
			return { ...state, GET_DEVICE_FUND_CONTRACTS_STATUS: 'SUCCESS' }
		case GET_DEVICE_FUND_CONTRACTS_REJECTED:
			return { ...state, GET_DEVICE_FUND_CONTRACTS_STATUS: 'FAILED'}
		case GET_ADDED_FUND_DEVICES_PENDING:
			return { ...state, GET_ADDED_FUND_DEVICES_STATUS: 'PENDING' }
		case GET_ADDED_FUND_DEVICES_FULFILLED:
			return { ...state, GET_ADDED_FUND_DEVICES_STATUS: 'SUCCESS'}
		case GET_ADDED_FUND_DEVICES_REJECTED:
			return { ...state, GET_ADDED_FUND_DEVICES_STATUS: 'FAILED'}
		case SET_DEVICE_FUNDS_PENDING:
			return { ...state, SET_DEVICE_FUNDS_STATUS: 'PENDING' }
		case SET_DEVICE_FUNDS_FULFILLED:
			return { ...state, SET_DEVICE_FUNDS_STATUS: 'SUCCESS'}
		case SET_DEVICE_FUNDS_REJECTED:
			return { ...state, SET_DEVICE_FUNDS_STATUS: 'FAILED' }
		case VALIDATE_PARENTID_HIERID_PENDING:
			return { ...state, VALIDATE_PARENTID_HIERID_STATUS: 'PENDING' }
		case VALIDATE_PARENTID_HIERID_FULFILLED:
			return { ...state, VALIDATE_PARENTID_HIERID_STATUS: 'SUCCESS' }
		case VALIDATE_PARENTID_HIERID_REJECTED:
			return { ...state, VALIDATE_PARENTID_HIERID_STATUS: 'FAILED' }
		case GET_PAYMENT_DETAILS_PENDING:
			return { ...state, GET_PAYMENT_DETAILS_STATUS: 'PENDING' }
		case GET_PAYMENT_DETAILS_FULFILLED:
			return { ...state, GET_PAYMENT_DETAILS_STATUS: 'SUCCESS' }
		case GET_PAYMENT_DETAILS_REJECTED:
			return { ...state, GET_PAYMENT_DETAILS_STATUS: 'FAILED' }
		case FETCH_ASSIGN_TO_LIST_PENDING:
			return { ...state, FETCH_ASSIGN_TO_LIST_STATUS: 'PENDING' }
		case FETCH_ASSIGN_TO_LIST_FULFILLED:
			return { ...state, FETCH_ASSIGN_TO_LIST_STATUS: 'SUCCESS' }
		case FETCH_ASSIGN_TO_LIST_REJECTED:
			return { ...state, FETCH_ASSIGN_TO_LIST_STATUS: 'FAILED' }
		case RESET_PARENTID_HIERID_STATUS_PENDING:
			return { ...state, VALIDATE_PARENTID_HIERID_STATUS: 'PENDING' }
		case RESET_PARENTID_HIERID_STATUS_FULFILLED:
			return { ...state, VALIDATE_PARENTID_HIERID_STATUS: 'SUCCESS' }
		case RESET_PARENTID_HIERID_STATUS_REJECTED:
			return { ...state, VALIDATE_PARENTID_HIERID_STATUS: 'FAILED' }
		case VAS_RULE_CHECK_PENDING:
			return { ...state, VAS_RULE_CHECK_STATUS: 'PENDING' }
		case VAS_RULE_CHECK_FULFILLED:
			return { ...state, VAS_RULE_CHECK_STATUS: 'SUCCESS' }
		case VAS_RULE_CHECK_REJECTED:
			return { ...state, VAS_RULE_CHECK_STATUS: 'FAILED' }
		case CONTRACT_CHECK_PENDING:
			return { ...state, CONTRACT_CHECK_STATUS: 'PENDING' }
		case CONTRACT_CHECK_FULFILLED:
			return { ...state, CONTRACT_CHECK_STATUS: 'SUCCESS' }
		case CONTRACT_CHECK_REJECTED:
			return { ...state, CONTRACT_CHECK_STATUS: 'FAILED' }
		case SET_APPROVAL_DEVICE_FUNDS_PENDING:
			return { ...state, SET_APPROVAL_DEVICE_FUNDS_STATUS: 'PENDING' }
		case SET_APPROVAL_DEVICE_FUNDS_FULFILLED:
			return { ...state, SET_APPROVAL_DEVICE_FUNDS_STATUS: 'SUCCESS' }
		case SET_APPROVAL_DEVICE_FUNDS_REJECTED:
			return { ...state, SET_APPROVAL_DEVICE_FUNDS_STATUS: 'FAILED' }
		case GET_VSN_DETAILS_PENDING:
			return { ...state, GET_VSN_DETAILS_STATUS: 'PENDING' }
		case GET_VSN_DETAILS_FULFILLED:
			return { ...state, GET_VSN_DETAILS_STATUS: 'SUCCESS' }
		case GET_VSN_DETAILS_REJECTED:
			return { ...state, GET_VSN_DETAILS_STATUS: 'FAILED' }
		case GET_PROMOTIONS_PENDING:
			return { ...state, GET_PROMOTIONS_STATUS: 'PENDING' }
		case GET_PROMOTIONS_FULFILLED:
			return { ...state, GET_PROMOTIONS_STATUS: 'SUCCESS' }
		case GET_PROMOTIONS_REJECTED:
			return { ...state, GET_PROMOTIONS_STATUS: 'FAILED' }
			case GET_DEVICE_LIST_ERF_PENDING:
			return { ...state, GET_DEVICE_LIST_ERF_STATUS: 'PENDING' }
		case GET_DEVICE_LIST_ERF_FULFILLED:
			return { ...state, GET_DEVICE_LIST_ERF_STATUS: 'SUCCESS' }
		case GET_DEVICE_LIST_ERF_REJECTED:
			return { ...state, GET_DEVICE_LIST_ERF_STATUS: 'FAILED' }
				case SET_OLD_DEVICE_FUNDS_PENDING:
			return { ...state, SET_OLD_DEVICE_FUNDS_STATUS: 'PENDING' }
		case SET_OLD_DEVICE_FUNDS_FULFILLED:
			return { ...state, SET_OLD_DEVICE_FUNDS_STATUS: 'SUCCESS'}
		case SET_OLD_DEVICE_FUNDS_REJECTED:
			return { ...state, SET_OLD_DEVICE_FUNDS_STATUS: 'FAILED' }
		case SEARCH_PAYMENT_PENDING:
			return { ...state, SEARCH_PAYMENT_STATUS: 'PENDING' }
		case SEARCH_PAYMENT_FULFILLED:
			return { ...state, SEARCH_PAYMENT_STATUS: 'SUCCESS' }
		case SEARCH_PAYMENT_REJECTED:
			return { ...state, SEARCH_PAYMENT_STATUS: 'FAILED' }
		case GET_PROD_GRP_CHANGE_PENDING:
			return { ...state, GET_PROD_GRP_CHANGE_STATUS: 'PENDING' }
		case GET_PROD_GRP_CHANGE_FULFILLED:
			return { ...state, GET_PROD_GRP_CHANGE_STATUS: 'SUCCESS' }
		case GET_PROD_GRP_CHANGE_REJECTED:
			return { ...state, GET_PROD_GRP_CHANGE_STATUS: 'FAILED' }
			case SEARCH_CHANGE_PENDING:
			return { ...state, SEARCH_CHANGE_STATUS: 'PENDING' }
		case SEARCH_CHANGE_FULFILLED:
			return { ...state, SEARCH_CHANGE_STATUS: 'SUCCESS' }
		case SEARCH_CHANGE_REJECTED:
			return { ...state, SEARCH_CHANGE_STATUS: 'FAILED' }
		case SEND_FILE_URL_DEALER_SEARCH_PENDING:
			return { ...state, SEND_FILE_URL_DEALER_SEARCH_STATUS: 'PENDING' }
		case SEND_FILE_URL_DEALER_SEARCH_FULFILLED:
			return { ...state, SEND_FILE_URL_DEALER_SEARCH_STATUS: 'SUCCESS'}
		case SEND_FILE_URL_DEALER_SEARCH_REJECTED:
			return { ...state, SEND_FILE_URL_DEALER_SEARCH_STATUS: 'FAILED' }
			case GET_AUTOMATED_REPORT_NAME_PENDING:
			return {...state, GET_AUTOMATED_REPORT_NAME_STATUS: 'PENDING'};
		case GET_AUTOMATED_REPORT_NAME_FULFILLED:
			return  {...state, GET_AUTOMATED_REPORT_NAME_STATUS: 'SUCCESS'};
		case GET_AUTOMATED_REPORT_NAME_REJECTED:
			return  {...state, GET_AUTOMATED_REPORT_NAME_STATUS: 'FAILED'};
		case GENERATE_REPORT_DATA_PENDING:
			return { ...state, GENERATE_REPORT_DATA_STATUS: 'PENDING' }
        	case GENERATE_REPORT_DATA_FULFILLED:
			return { ...state, GENERATE_REPORT_DATA_STATUS: 'SUCCESS' }
       		case GENERATE_REPORT_DATA_REJECTED:
			return { ...state, GENERATE_REPORT_DATA_STATUS: 'FAILED' }
		case GET_REPORTS_EXECUTION_HISTORY_PENDING:
			return { ...state, GET_REPORTS_EXECUTION_HISTORY_STATUS: 'PENDING' }
        	case GET_REPORTS_EXECUTION_HISTORY_FULFILLED:
			return { ...state, GET_REPORTS_EXECUTION_HISTORY_STATUS: 'SUCCESS' }
        	case GET_REPORTS_EXECUTION_HISTORY_REJECTED:
			return { ...state, GET_REPORTS_EXECUTION_HISTORY_STATUS: 'FAILED' }
		case GET_CUSTOM_REPORT_INPUTS_PENDING:
			return { ...state, GET_CUSTOM_REPORT_INPUTS_STATUS: 'PENDING' }
        case GET_CUSTOM_REPORT_INPUTS_FULFILLED:
			return { ...state, GET_CUSTOM_REPORT_INPUTS_STATUS: 'SUCCESS' }
        case GET_CUSTOM_REPORT_INPUTS_REJECTED:
			return { ...state, GET_CUSTOM_REPORT_INPUTS_STATUS: 'FAILED' }
			case FETCH_REG_TYPES_OBS_PENDING:
			return {...state, FETCH_REG_TYPES_OBS_STATUS:'PENDING'}
		case FETCH_REG_TYPES_OBS_FULFILLED:
			return {...state, FETCH_REG_TYPES_OBS_STATUS:'SUCCESS'}
		case FETCH_REG_TYPES_OBS_REJECTED:
			return {...state, FETCH_REG_TYPES_OBS_STATUS:'FAILED'}
			case FETCH_RATEPLANS_OBS_PENDING:
			return {...state,FETCH_RATEPLANS_OBS_STATUS:'PENDING'}
		case FETCH_RATEPLANS_OBS_FULFILLED:
			return {...state, FETCH_RATEPLANS_OBS_STATUS:'SUCCESS'}
		case FETCH_RATEPLANS_OBS_REJECTED:
			return {...state, FETCH_RATEPLANS_OBS_STATUS:'FAILED'}
			case VSN_OBS_SEARCH_BY_BRN_PENDING:
			return {...state, VSN_OBS_SEARCH_BY_BRN_STATUS: 'PENDING'};
		case VSN_OBS_SEARCH_BY_BRN_FULFILLED:
			return  {...state, VSN_OBS_SEARCH_BY_BRN_STATUS: 'SUCCESS'};
		case VSN_OBS_SEARCH_BY_BRN_REJECTED:
			return  {...state, VSN_OBS_SEARCH_BY_BRN_STATUS: 'FAILED'};
		case GET_BCC_VALIDATION_PENDING:
			return { ...state, GET_BCC_VALIDATION_STATUS: 'PENDING' }
		case GET_BCC_VALIDATION_FULFILLED:
			return { ...state, GET_BCC_VALIDATION_STATUS: 'SUCCESS' }
		case GET_BCC_VALIDATION_REJECTED:
			return { ...state, GET_BCC_VALIDATION_STATUS: 'FAILED'}	
		case GET_RATEPLAN_DEVICE_MAP_LIST_PENDING:
			return { ...state, GET_RATEPLAN_DEVICE_MAP_LIST_STATUS: 'PENDING' }
		case GET_RATEPLAN_DEVICE_MAP_LIST_FULFILLED:
			return { ...state, GET_RATEPLAN_DEVICE_MAP_LIST_STATUS: 'SUCCESS' }
		case GET_RATEPLAN_DEVICE_MAP_LIST_REJECTED:
			return { ...state, GET_RATEPLAN_DEVICE_MAP_LIST_STATUS: 'FAILED' }
		case VALIDATE_LINE_EXISTING_GROUP_PENDING:
			return { ...state, VALIDATE_LINE_EXISTING_GROUP_STATUS: 'PENDING' }
		case VALIDATE_LINE_EXISTING_GROUP_FULFILLED:
			return { ...state, VALIDATE_LINE_EXISTING_GROUP_STATUS: 'SUCCESS' }
		case VALIDATE_LINE_EXISTING_GROUP_REJECTED:
			return { ...state, VALIDATE_LINE_EXISTING_GROUP_STATUS: 'FAILED' }
        	case GET_BULK_USERS_PENDING:
			return { ...state, GET_BULK_USERS_STATUS: 'PENDING' }
		case GET_BULK_USERS_FULFILLED:
			return { ...state, GET_BULK_USERS_STATUS: 'SUCCESS' }
		case GET_BULK_USERS_REJECTED:
			return { ...state, GET_BULK_USERS_STATUS: 'FAILED' }
		case GET_BULK_ORDERS_DATA_PENDING:
			return { ...state, GET_BULK_ORDERS_DATA_STATUS: 'PENDING' }
		case GET_BULK_ORDERS_DATA_FULFILLED:
			return { ...state, GET_BULK_ORDERS_DATA_STATUS: 'SUCCESS' }
		case GET_BULK_ORDERS_DATA_REJECTED:
			return { ...state, GET_BULK_ORDERS_DATA_STATUS: 'FAILED' }
			case GET_SIM_TYPE_REPLCMT_REASON_PENDING:
			return { ...state, GET_SIM_TYPE_REPLCMT_REASON_STATUS: 'PENDING' }
		case GET_SIM_TYPE_REPLCMT_REASON_FULFILLED:
			return { ...state, GET_SIM_TYPE_REPLCMT_REASON_STATUS: 'SUCCESS' }
		case GET_SIM_TYPE_REPLCMT_REASON_REJECTED:
			return { ...state, GET_SIM_TYPE_REPLCMT_REASON_STATUS: 'FAILED' }
		case GET_TEMPLATE_BULKSIM_FULFILLED:
			return { ...state, GET_TEMPLATE_BULKSIM_STATUS: 'SUCCESS' }
		case GET_TEMPLATE_BULKSIM_PENDING:
			return { ...state, GET_TEMPLATE_BULKSIM_STATUS: 'PENDING' }
		case GET_TEMPLATE_BULKSIM_REJECTED:
			return { ...state, GET_TEMPLATE_BULKSIM_STATUS: 'FAILED' }
		case GET_OBS_DEVICES_PENDING:
			return { ...state, GET_OBS_DEVICES_STATUS: 'PENDING' }
		case GET_OBS_DEVICES_FULFILLED:
			return { ...state, GET_OBS_DEVICES_STATUS: 'SUCCESS' }
		case GET_OBS_DEVICES_REJECTED:
			return { ...state, GET_OBS_DEVICES_STATUS: 'FAILED' }
		case FETCH_OBS_DEVICE_INFO_PENDING:
			return {...state, FETCH_OBS_DEVICE_INFO_STATUS: 'PENDING'}
		case FETCH_OBS_DEVICE_INFO_FULFILLED:
			return {...state, FETCH_OBS_DEVICE_INFO_STATUS: 'SUCCESS'}
		case FETCH_OBS_DEVICE_INFO_REJECTED:
			return {...state, FETCH_OBS_DEVICE_INFO_STATUS: 'FAILED'}
		default:
			return state;
	}
}

function dataReducer(state = initialDataState, action) {
	switch (action.type) {
		case GET_EAS_CONFIGURATION_DATA_FULFILLED:
		console.log("tempMaxLineCount",action.payload.data.maxLineCount)
			return {
				...state,
				bundleTypes: action.payload.data.bundleTypes,
				orderCategories: action.payload.data.orderCategories,
				tempMaxLineCount:action.payload.data.maxLineCount
			}
		case VSN_SEARCH_BY_BRN_FULFILLED:
		 	return {
		 		...state,
		 		vsnServices: action.payload.data
		 	}
		 case VSN_SEARCH_BY_BRN_REJECTED:
		  	return {
		  		...state,
		  		errorMessage:action.payload.response.data.errorMessage,
		  	}
		case VSN_SEARCH_BY_MSISDN_VSN_FULFILLED:
			return{
				...state,
				vsnServices: action.payload.data
			}
		case VSN_SEARCH_BY_MSISDN_VSN_REJECTED:
			return  {
				...state,
				errorMessage:action.payload.response.data[0].errorMessage,
				vsnServices:[]
			}
		case FETCH_REG_TYPES_FULFILLED:
			return {...state,
					regTypes:action.payload.data
			}
		case FETCH_RATEPLANS_FULFILLED:
			return {...state,
					ratePlans:action.payload.data
			}
		case FETCH_SIM_TYPES_FULFILLED:
			return {...state,
					simTypes:action.payload.data
			}
		case FETCH_ZEROLUTION_DEVICES_FULFILLED:
			return {...state,
					zerolutionDevices:action.payload.data
			}
		case GET_DEVICE_LIST_ERF_FULFILLED:
			return {...state,
					deviceListERF:action.payload.data
			}
		case FETCH_DONOR_TYPES_FULFILLED:
			return {...state,
					donorTypes:action.payload.data
			}
		case COMPANY_INFO_BY_BRN_FULFILLED:
			return {
				...state,
				brnInfo: action.payload.data.brnInfo
			}
		case COMPANY_INFO_BY_BRN_REJECTED:
			return {
				...state,
				errorMessage: action.payload.response.data.brnInfo.errorMessage
			}
		case FETCH_ZEROLUTION_DEVICE_INFO_FULFILLED:
			return {...state,
					lineDeviceInfo:action.payload.data
			}
		case FETCH_DEVICE_FUNDS_FULFILLED:
			return {...state,
					...action.payload.data
			}
		case FETCH_FLEXI_FUND_DEVICES_FULFILLED:
			return {...state,
					flexiFundDevices:action.payload.data
			}
		case SEND_FILE_FULFILLED:
			return {
				...state,
				uploadedDocDetails: action.payload.data
			}
		case GET_UPLOADED_FILE_FULFILLED:

			return {
				...state,

				regDoc: action.payload.data
			}
		case FETCH_POST_CODE_HINT_FULFILLED:
			return { ...state,
					postCodeHint: action.payload.data
			}
		case SUBMISSION_INFO_FULFILLED:
			return {
				...state,
				...action.payload
			}
		case ACCOUNT_MANAGER_INFO_FULFILLED:
			return {
				...state,
				accMngrList: action.payload.data
			}
		case SUPPORTING_CENTER_INFO_FULFILLED:
			return {
				...state,
				suppcenterList: action.payload.data
			}
		case SUBMISSION_SEND_FILE_FULFILLED:
			return {
				...state,
				uploadedDocDetails: action.payload.data
			}
		case SUBMISSION_UPLOAD_FILE_FULFILLED:
			return {
				...state,
				regDoc:action.payload.data
			}
		case FETCH_VAS_POPUP_DATA_FULFILLED:
			return { ...state,
					vasOptionals:action.payload.data.vasOptionals,
					vasMandatory:action.payload.data.vasMandatory,
					vasContracts:action.payload.data.vasContracts,
					vasIddCountries:action.payload.data.vasIddCountries,
					flexiFundContractTaken:action.payload.data.flexiFundContractTaken,
					byodContractTaken:action.payload.data.byodContractTaken,
					oldComponentList:action.payload.data.oldComponentList
			}
		case VALIDATE_LINE_FULFILLED:
			return { ...state,
					 isLineDataValid:true
			}
		case VALIDATE_LINE_REJECTED:
			return { ...state,
					 validateErrorMessage:action.payload.response.data.errorMessage,
					 isLineDataValid:false
			}
		case FETCH_DEVICE_FUND_CONTRACTS_FULFILLED:
			return { ...state,
						deviceFunds:action.payload.data.fundDetailsListNew,
						deviceFundsOld:action.payload.data.fundDetailsListOld
			}
		case FETCH_FUND_DEVICE_INFO_FULFILLED:
			return { ...state,
					 fundDeviceInfo: action.payload.data
			}
		case GET_DEVICE_FUND_CONTRACTS_FULFILLED:
		console.log('Device Funds', action.payload.data);
			return { ...state,
					deviceFunds:action.payload.data.fundDetailsListNew,
					deviceFundsOld:action.payload.data.fundDetailsListOld
			}
		case GET_ADDED_FUND_DEVICES_FULFILLED:
			return { ...state,
					addedFundDevices:action.payload.data
			}
		case SET_DEVICE_FUNDS_FULFILLED:
			return { ...state,
					...action.payload
			}
		case APPROVAL_SUBMISSION_INFO_FULFILLED:
			return {
				...state,
				...action.payload
			}
		case VALIDATE_PARENTID_HIERID_FULFILLED:
			return {
				...state,
				authList:action.payload.data.parentHierConfig[0].authList,
				marketCode:action.payload.data.parentHierConfig[0].marketCode,
				marketCodeName:action.payload.data.parentHierConfig[0].marketCodeName,
				collectionCodeName:action.payload.data.parentHierConfig[0].collectionCodeName,
				collectionCode:action.payload.data.parentHierConfig[0].collectionCode,
				accountCategory:action.payload.data.parentHierConfig[0].accountCategory,
				error:action.payload.data.parentHierConfig[0].error,
				errorMessage:action.payload.data.parentHierConfig[0].errorMessage
			}
			case VALIDATE_PARENTID_HIERID_REJECTED:
				return {
					...state,
					//...action.payload.data,
					errorMessage:action.payload.response.data.parentHierConfig[0].errorMessage
				}
			case GET_PAYMENT_DETAILS_FULFILLED:
			return {
					...state,
					paymentDetails:action.payload.data
				}
				case GET_VIEW_SUBMISSION_INFO_FULFILLED:
				return {
						...state,
						paymentDetails:action.payload.data
					}
			case FETCH_ASSIGN_TO_LIST_FULFILLED:
				return { ...state,
						assignList:action.payload.data
				}
			case RESET_PARENTID_HIERID_STATUS_FULFILLED:
				return { ...state,
				}
			case VAS_RULE_CHECK_FULFILLED:
				return { ...state  }
			case VAS_RULE_CHECK_REJECTED:
				return { ...state, vasMessage:action.payload.response.data.errorMsg }
			case CONTRACT_CHECK_FULFILLED:
				return { ...state,
						msisdnContracts:action.payload.data
				}
			case CONTRACT_CHECK_REJECTED:
				return { ...state,
						msisdnContracts:action.payload.response.data
				}
			case SET_APPROVAL_DEVICE_FUNDS_FULFILLED:
				return { ...state, ...action.payload}
			case GET_VSN_DETAILS_FULFILLED:
				return { ...state,
					lineCount:action.payload.data.lineCount,
					maxLineCount:action.payload.data.maxLineCount,
					brnByVsn:action.payload.data.brnByVsn,
					isValidVSN:true
				}
			case GET_VSN_DETAILS_REJECTED:
				return { ...state, errorMessage:action.payload.response.data }

			case GET_PROMOTIONS_FULFILLED:
			return {...state,
					promotions:action.payload.data
			}
			case SET_OLD_DEVICE_FUNDS_FULFILLED:
				return { ...state,
						...action.payload
				}
			case SEARCH_PAYMENT_FULFILLED:
				return { ...state,
						paymentInfo :action.payload.data
				}
			case GET_PROD_GRP_CHANGE_FULFILLED:
				return { ...state,
						bundleTypes :action.payload.data
				}
			case SEARCH_CHANGE_FULFILLED:
				return { ...state,
						changeStatusRegIdList :action.payload.data
				}
			case SEND_FILE_URL_DEALER_SEARCH_FULFILLED:
				return {
						...state,
						tempDocRegId: action.payload.data.documentRegId
				}
			case GET_AUTOMATED_REPORT_NAME_FULFILLED:
				return {
				...state,
				reportTypes: action.payload.data }
			case GET_AUTOMATED_REPORT_NAME_FULFILLED:
				return {
				...state,
				reportTypes: action.payload.data }
			case GET_REPORTS_EXECUTION_HISTORY_FULFILLED:
			
				return { ...state, 
						 reportHistoryExecutionData:action.payload.data
				}
			case GET_REPORTS_EXECUTION_HISTORY_REJECTED:
				return { ...state
				}
			case GET_CUSTOM_REPORT_INPUTS_FULFILLED:
				return { ...state, 
						 reportInputs:action.payload.data
				}
			case GET_CUSTOM_REPORT_INPUTS_REJECTED:
				return { ...state
				}
				case FETCH_REG_TYPES_OBS_FULFILLED:
				return {...state,
						regTypes:action.payload.data
				}
			case FETCH_RATEPLANS_OBS_FULFILLED:
				return {...state,
						ratePlans:action.payload.data
				}
				case VSN_OBS_SEARCH_BY_BRN_FULFILLED:
				return {
					...state,
					vsnServices: action.payload.data
				}
			case VSN_OBS_SEARCH_BY_BRN_REJECTED:
			console.log(action.payload)
				 return {
					 ...state,
					 errorMessage:action.payload.response.data[0].errorMessage
				 }
			case GET_BCC_VALIDATION_FULFILLED:
				return { ...state,
					bccValidationFailed:action.payload.data.bccValidationFailed,
					bccErrorMessage:action.payload.data.errorMessage
				}
			case GET_BCC_VALIDATION_REJECTED:
				return { ...state, bccErrorMessage:action.payload.response.data.errMsg }	
				case GET_RATEPLAN_DEVICE_MAP_LIST_FULFILLED:
			return {...state,
					ratePlanDeviceMapList:action.payload.data
			}

			case VALIDATE_LINE_EXISTING_GROUP_FULFILLED:
			return{
				...state,
				validatedDeviceList : action.payload.data.deviceList
			}
			
				case GET_BULK_USERS_FULFILLED:
				return { ...state,
					bulkUsers: action.payload.data.bulkUsers,
       				bulkRegTypes:action.payload.data.bulkRegTypeList,
        			statusList:action.payload.data.statusList,
				}

			case GET_BULK_ORDERS_DATA_FULFILLED:
				return{
					...state,
					bulkOrders: action.payload.data
				}
				
				case GET_SIM_TYPE_REPLCMT_REASON_FULFILLED:
				return { ...state,
					bulkUsers: action.payload.data.bulkUsers,
        			statusList:action.payload.data.statusList,
				}

			case GET_TEMPLATE_BULKSIM_FULFILLED:
			console.log('hi i having file'+ action.payload.data)
			return {
				...state,
				downloadFileBulkSim: action.payload.data
			}
			case GET_OBS_DEVICES_FULFILLED:
			return {
				...state, obsDevices: action.payload.data
			}
			case FETCH_OBS_DEVICE_INFO_FULFILLED:
			return {...state,
				lineDeviceInfo:action.payload.data
			}

			default:
			return state;
	}
}

export default combineReducers({
	meta: metaReducer,
	data: dataReducer
});
