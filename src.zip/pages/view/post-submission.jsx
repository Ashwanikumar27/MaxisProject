import React, { Component } from 'react';

export default class PostSubmission extends Component {
	render() {
		return (
			<div></div>
		);
	}
}
